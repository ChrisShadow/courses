# Importamos las librerías necesarias
import pandas as pd
import numpy as np
import nltk
import spacy
import matplotlib.pyplot as plt
import pickle
import json
import argparse
import os
import subprocess
import tensorflow as tf

from datetime import datetime
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import roc_curve, auc
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Embedding, LSTM, Dense, SpatialDropout1D
from tensorflow.keras.utils import to_categorical
from sklearn.metrics import roc_curve, auc

# Vamos a utilizar NLTK para filtrar stopwords
nltk.download('punkt')
nltk.download('stopwords')


# Método principal
def main(args):
    os.environ["CUDA_VISIBLE_DEVICES"] = "-1"

    # Descargar el modelo de SpaCy si no está disponible
    try:
        nlp = spacy.load('es_core_news_md')
    except OSError:
        subprocess.run(["python", "-m", "spacy", "download", "es_core_news_md"])
        nlp = spacy.load('es_core_news_md')

    # Cargar los datos de entrenamiento desde la ruta del archivo JSON
    with open(args.training_data, 'r') as f:
        data = json.load(f)

    df = pd.DataFrame(data)

    # Preprocesar texto usando una función lambda para pasar nlp
    df['processed_text'] = df['text'].apply(lambda x: preprocess_text(x, nlp))

    # Tokenizamos el texto
    tokenizer = Tokenizer(num_words=500, split=' ')
    tokenizer.fit_on_texts(df['processed_text'].values)

    X = tokenizer.texts_to_sequences(df['processed_text'].values)
    X = pad_sequences(X, maxlen=5)

    # Creamos el encoder de los labels o salidas:
    Y = pd.get_dummies(df['category']).values

    # Dividimos la imformación en entrenamiento y validación (pruebas)
    X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.10, random_state=42)

    model = model_build(X, Y, tokenizer)

    # Train the model
    batch_size = 1
    history = model.fit(X_train, Y_train, epochs=10, batch_size=batch_size, validation_data=(X_test, Y_test), verbose=2)

    # Evaluamos el modelo
    score, acc = model.evaluate(X_test, Y_test, verbose=2, batch_size=batch_size)

    # Guardar el modelo y el tokenizador
    model.save('chatbot_model_auto.h5')
    with open('tokenizer_auto.pickle', 'wb') as handle:
        pickle.dump(tokenizer, handle, protocol=pickle.HIGHEST_PROTOCOL)

    # Evaluamos el modelo
    eval_model(model, X_test, Y_test, history)


# Preprocesamos el text
def preprocess_text(text, nlp):
    doc = nlp(text)
    tokens = [token.lemma_.lower() for token in doc if not token.is_stop and token.is_alpha]
    return ' '.join(tokens)


# Construimos el modelo
def model_build(X, Y, tokenizer):
    model = Sequential()
    model.add(Embedding(len(tokenizer.word_index)+1, 50, input_length=X.shape[1]))
    model.add(SpatialDropout1D(0.2))
    model.add(LSTM(50, dropout=0.2, recurrent_dropout=0.2))
    model.add(Dense(len(Y[0]), activation='softmax'))
    model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
    return model


# function that evaluates the model
def eval_model(model, X_test, y_test, history):
    # calculate accuracy
    y_hat = model.predict(X_test)
    acc = np.average(y_hat == y_test)
    print('Accuracy:', acc)

    print('Accuracy history', history.history['accuracy'])
    print('Val Accuracy history', history.history['val_accuracy'])
    print('Loss history', history.history['loss'])
    print('Val Loss history', history.history['val_loss'])


def parse_args():
    # setup arg parser
    parser = argparse.ArgumentParser()

    # add arguments
    parser.add_argument("--training_data", dest='training_data',
                        type=str)

    # parse args
    args = parser.parse_args()

    # return args
    return args


# run script
if __name__ == "__main__":
    # add space in logs
    print("\n\n")
    print("*" * 60)

    # parse args
    args = parse_args()

    # run main function
    main(args)

    # add space in logs
    print("*" * 60)
    print("\n\n")
