# Librerías necesarias para la instalación

Recuerda que si no estás en el ambiente correcto, deberás de abrir la terminal y activarlo, puedes verificar qué ambientes tienes con el siguiente comando:

```bash
conda env list
```

Después, deberás de activar el amebiente correspondiente con:

```bash
conda activate <nombre_ambiente>
```

Para instalar alguna librería o dependencia que te haga falta lo puedes hacer con:
```bash
pip install <librería>
```
por ejemplo:
```bash
pip install spacy
```

Debemos descargar el modelo core de spacy:
```bash
python -m spacy download es_core_news_md
```
