#ifndef DS_HASHABLE_CE_H
#define DS_HASHABLE_CE_H

#include "php.h"

extern zend_class_entry *hashable_ce;

void php_ds_register_hashable();

#endif
